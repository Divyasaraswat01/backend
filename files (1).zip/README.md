# 🚕 Tummy Taxi — Food Delivery App

A complete food delivery application built with PHP, MySQL, and vanilla JavaScript.

---

## 📁 Project Structure

```
tummy-taxi/
├── backend/
│   ├── config/
│   │   ├── database.php        ← DB connection (PDO)
│   │   └── helpers.php         ← JWT auth, response helpers
│   ├── api/
│   │   ├── auth.php            ← Register / Login / Profile
│   │   ├── restaurants.php     ← List / Detail / CRUD
│   │   ├── cart.php            ← Add / Update / Clear cart
│   │   ├── orders.php          ← Place / Track / Update orders
│   │   ├── reviews.php         ← Submit reviews
│   │   └── admin.php           ← Admin stats & management
│   └── database.sql            ← Full DB schema + seed data
├── frontend/
│   ├── index.html              ← Customer-facing app
│   └── admin.html              ← Admin dashboard
└── .htaccess                   ← URL rewriting
```

---

## ⚙️ Setup Instructions

### 1. Prerequisites
- PHP 8.0+ with PDO_MySQL extension
- MySQL 8.0+
- Apache/Nginx with mod_rewrite enabled (or PHP built-in server)

### 2. Database Setup

```sql
-- Run the schema file in MySQL Workbench / phpMyAdmin / CLI:
mysql -u root -p < backend/database.sql
```

### 3. Configure Database Connection

Edit `backend/config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'tummy_taxi');
define('DB_USER', 'your_mysql_user');
define('DB_PASS', 'your_mysql_password');
```

### 4. Run the Application

**Option A — Apache/Nginx (recommended):**
- Point document root to the `tummy-taxi/` folder
- Enable mod_rewrite (Apache) or configure try_files (Nginx)
- Open `http://localhost/frontend/index.html`

**Option B — PHP Built-in Server:**
```bash
cd tummy-taxi
php -S localhost:8000
# Open: http://localhost:8000/frontend/index.html
# Admin: http://localhost:8000/frontend/admin.html
```

---

## 🔑 Demo Credentials

| Role      | Email                    | Password    |
|-----------|--------------------------|-------------|
| Admin     | admin@tummytaxi.com      | admin123    |
| Customer  | customer@demo.com        | customer123 |

> **Note:** The password hashes in seed data are placeholders. Run this to generate real ones:
```php
<?php echo password_hash('admin123', PASSWORD_BCRYPT); ?>
```
Then UPDATE the `password_hash` column for each user in MySQL.

---

## 🗄️ Database Design

### Core Tables
| Table | Description |
|-------|-------------|
| `users` | All users (customers, owners, agents, admins) |
| `addresses` | Delivery addresses per user |
| `restaurants` | Restaurant profiles |
| `menu_categories` | Menu sections per restaurant |
| `menu_items` | Individual dishes |
| `cart_items` | Server-side shopping cart |
| `orders` | Order records |
| `order_items` | Snapshot of ordered items |
| `order_status_history` | Full audit trail |
| `reviews` | Food + delivery ratings |
| `coupons` | Discount codes |
| `notifications` | In-app alerts |

### Views
- `v_restaurant_summary` — aggregated restaurant data
- `v_order_detail` — full order with joins

### Stored Procedures
- `sp_place_order` — atomic order creation (cart → order, coupon apply, cart clear)
- `sp_update_restaurant_rating` — recalculate avg rating

### Triggers
- Auto-update restaurant rating on review insert/update
- Log order status changes automatically

---

## 🌐 API Endpoints

### Auth (`/backend/api/auth.php`)
| Method | Action | Auth |
|--------|--------|------|
| POST | `?action=register` | — |
| POST | `?action=login` | — |
| GET  | `?action=me` | ✅ |
| PUT  | `?action=update` | ✅ |

### Restaurants (`/backend/api/restaurants.php`)
| Method | Params | Auth |
|--------|--------|------|
| GET | `?city=&cuisine=&search=&sort=` | — |
| GET | `?id=1` | — |
| POST | (body) | Owner/Admin |
| PUT | `?id=1` (body) | Owner/Admin |

### Cart (`/backend/api/cart.php`)
| Method | Description | Auth |
|--------|-------------|------|
| GET | Get cart items | ✅ |
| POST | Add/update item | ✅ |
| DELETE | `?item_id=1` or clear all | ✅ |

### Orders (`/backend/api/orders.php`)
| Method | Description | Auth |
|--------|-------------|------|
| GET | List orders / `?id=1` detail | ✅ |
| POST | Place order | Customer |
| PUT | `?id=1` update status | Owner/Agent/Admin |
| DELETE | `?id=1` cancel | Customer |

### Admin (`/backend/api/admin.php`)
| GET action | Description |
|------------|-------------|
| `stats` | Dashboard KPIs |
| `pending_restaurants` | Unapproved restaurants |
| `users` | All users |

---

## ✨ Features

**Customer**
- Browse restaurants by cuisine, city, rating
- Full menu with veg/non-veg indicators
- Add to cart (single-restaurant enforcement)
- Apply coupon codes
- Place & track orders in real-time
- Review food + delivery after completion

**Restaurant Owner**
- Submit restaurant for approval
- Manage menu categories & items
- View & update incoming orders
- See reviews & ratings

**Delivery Agent**
- View assigned orders
- Update pickup/delivery status

**Admin Dashboard**
- KPI overview (revenue, orders, users)
- Approve/reject restaurant listings
- Manage all users
- Full order management

---

## 🔒 Security Notes

1. Change `JWT_SECRET` in `helpers.php` before production
2. Hash passwords with `PASSWORD_BCRYPT` (already enforced)
3. All inputs use PDO prepared statements (SQL injection safe)
4. CORS is open (`*`) — restrict to your domain in production
5. Add HTTPS in production

---

*Built with ❤️ for Jaipur's food lovers*
