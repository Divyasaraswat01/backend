<?php
// backend/api/auth.php

require_once __DIR__ . '/../config/helpers.php';

$db     = Database::connect();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// POST /api/auth.php?action=register
if ($method === 'POST' && $action === 'register') {
    $body = get_body();
    validate($body, [
        'name'     => 'required',
        'email'    => 'required|email',
        'phone'    => 'required',
        'password' => 'required|min:6',
    ]);

    $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$body['email']]);
    if ($stmt->fetch()) error('Email already registered');

    $hash = password_hash($body['password'], PASSWORD_BCRYPT);
    $stmt = $db->prepare(
        'INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?,?)'
    );
    $stmt->execute([
        trim($body['name']),
        strtolower(trim($body['email'])),
        $body['phone'],
        $hash,
        $body['role'] ?? 'customer',
    ]);
    $userId = $db->lastInsertId();

    $token = jwt_encode(['id' => $userId, 'email' => $body['email'], 'role' => $body['role'] ?? 'customer']);
    success(['token' => $token, 'user_id' => $userId], 'Registration successful', 201);
}

// POST /api/auth.php?action=login
if ($method === 'POST' && $action === 'login') {
    $body = get_body();
    validate($body, ['email' => 'required|email', 'password' => 'required']);

    $stmt = $db->prepare('SELECT * FROM users WHERE email = ? AND is_active = 1');
    $stmt->execute([strtolower(trim($body['email']))]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($body['password'], $user['password_hash'])) {
        error('Invalid email or password');
    }

    $token = jwt_encode(['id' => $user['id'], 'email' => $user['email'], 'role' => $user['role']]);
    unset($user['password_hash']);
    success(['token' => $token, 'user' => $user], 'Login successful');
}

// GET /api/auth.php?action=me
if ($method === 'GET' && $action === 'me') {
    $auth = require_auth();
    $stmt = $db->prepare('SELECT id, name, email, phone, role, avatar_url, created_at FROM users WHERE id = ?');
    $stmt->execute([$auth['id']]);
    $user = $stmt->fetch();
    if (!$user) error('User not found', 404);
    success($user);
}

// PUT /api/auth.php?action=update
if ($method === 'PUT' && $action === 'update') {
    $auth = require_auth();
    $body = get_body();
    $db->prepare('UPDATE users SET name=?, phone=? WHERE id=?')
       ->execute([trim($body['name'] ?? ''), $body['phone'] ?? '', $auth['id']]);
    success([], 'Profile updated');
}

error('Invalid action or method', 404);
