<?php
// backend/api/cart.php

require_once __DIR__ . '/../config/helpers.php';

$db     = Database::connect();
$method = $_SERVER['REQUEST_METHOD'];

// GET cart
if ($method === 'GET') {
    $auth = require_auth();
    $stmt = $db->prepare(
        'SELECT ci.id, ci.menu_item_id, ci.quantity, ci.notes,
                mi.name, mi.price, mi.image_url, mi.is_veg,
                mi.restaurant_id,
                (ci.quantity * mi.price) AS subtotal
         FROM   cart_items ci
         JOIN   menu_items mi ON mi.id = ci.menu_item_id
         WHERE  ci.user_id = ?
         ORDER  BY ci.created_at'
    );
    $stmt->execute([$auth['id']]);
    $items = $stmt->fetchAll();

    $totals = [
        'item_count'  => array_sum(array_column($items, 'quantity')),
        'subtotal'    => array_sum(array_column($items, 'subtotal')),
        'restaurant_id' => $items[0]['restaurant_id'] ?? null,
    ];
    success(['items' => $items, 'totals' => $totals]);
}

// POST – add/update item
if ($method === 'POST') {
    $auth = require_auth(['customer']);
    $body = get_body();
    validate($body, ['menu_item_id' => 'required']);

    $menuItemId = (int)$body['menu_item_id'];
    $quantity   = max(1, (int)($body['quantity'] ?? 1));

    // Verify item exists
    $stmt = $db->prepare('SELECT restaurant_id FROM menu_items WHERE id = ? AND is_available = 1');
    $stmt->execute([$menuItemId]);
    $item = $stmt->fetch();
    if (!$item) error('Item not available');

    // Enforce single-restaurant cart
    $stmt = $db->prepare(
        'SELECT DISTINCT mi.restaurant_id FROM cart_items ci
         JOIN menu_items mi ON mi.id = ci.menu_item_id
         WHERE ci.user_id = ?'
    );
    $stmt->execute([$auth['id']]);
    $existing = $stmt->fetchColumn();
    if ($existing && $existing != $item['restaurant_id']) {
        error('Your cart has items from another restaurant. Clear cart first.');
    }

    $stmt = $db->prepare(
        'INSERT INTO cart_items (user_id, menu_item_id, quantity, notes)
         VALUES (?,?,?,?)
         ON DUPLICATE KEY UPDATE quantity = ?, notes = ?'
    );
    $stmt->execute([
        $auth['id'], $menuItemId, $quantity, $body['notes'] ?? null,
        $quantity, $body['notes'] ?? null,
    ]);
    success([], 'Cart updated');
}

// DELETE – remove item or clear cart
if ($method === 'DELETE') {
    $auth       = require_auth();
    $menuItemId = (int)($_GET['item_id'] ?? 0);
    if ($menuItemId) {
        $db->prepare('DELETE FROM cart_items WHERE user_id=? AND menu_item_id=?')
           ->execute([$auth['id'], $menuItemId]);
        success([], 'Item removed');
    }
    // Clear entire cart
    $db->prepare('DELETE FROM cart_items WHERE user_id=?')->execute([$auth['id']]);
    success([], 'Cart cleared');
}

error('Not found', 404);
