-- ============================================================
--  TUMMY TAXI — Complete Database Schema
--  Database: MySQL 8.0+
-- ============================================================

CREATE DATABASE IF NOT EXISTS tummy_taxi
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE tummy_taxi;

-- ─────────────────────────────────────────
-- 1. USERS
-- ─────────────────────────────────────────
CREATE TABLE users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100)  NOT NULL,
    email         VARCHAR(150)  NOT NULL UNIQUE,
    phone         VARCHAR(20)   NOT NULL,
    password_hash VARCHAR(255)  NOT NULL,
    role          ENUM('customer','restaurant_owner','delivery_agent','admin')
                                NOT NULL DEFAULT 'customer',
    avatar_url    VARCHAR(500)  DEFAULT NULL,
    is_active     TINYINT(1)    NOT NULL DEFAULT 1,
    created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_role  (role)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 2. ADDRESSES
-- ─────────────────────────────────────────
CREATE TABLE addresses (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    label       VARCHAR(50)  NOT NULL DEFAULT 'Home',   -- Home / Work / Other
    line1       VARCHAR(200) NOT NULL,
    line2       VARCHAR(200) DEFAULT NULL,
    city        VARCHAR(100) NOT NULL,
    state       VARCHAR(100) NOT NULL,
    pincode     VARCHAR(10)  NOT NULL,
    latitude    DECIMAL(10,7) DEFAULT NULL,
    longitude   DECIMAL(10,7) DEFAULT NULL,
    is_default  TINYINT(1)  NOT NULL DEFAULT 0,
    created_at  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 3. RESTAURANTS
-- ─────────────────────────────────────────
CREATE TABLE restaurants (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    owner_id         INT UNSIGNED NOT NULL,
    name             VARCHAR(150) NOT NULL,
    slug             VARCHAR(170) NOT NULL UNIQUE,
    description      TEXT         DEFAULT NULL,
    cuisine_type     VARCHAR(100) NOT NULL,
    logo_url         VARCHAR(500) DEFAULT NULL,
    cover_url        VARCHAR(500) DEFAULT NULL,
    address_line     VARCHAR(300) NOT NULL,
    city             VARCHAR(100) NOT NULL,
    pincode          VARCHAR(10)  NOT NULL,
    latitude         DECIMAL(10,7) DEFAULT NULL,
    longitude        DECIMAL(10,7) DEFAULT NULL,
    phone            VARCHAR(20)  NOT NULL,
    email            VARCHAR(150) DEFAULT NULL,
    avg_rating       DECIMAL(3,2) NOT NULL DEFAULT 0.00,
    total_reviews    INT UNSIGNED NOT NULL DEFAULT 0,
    min_order_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    delivery_fee     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    avg_delivery_min INT UNSIGNED NOT NULL DEFAULT 30,
    is_open          TINYINT(1)   NOT NULL DEFAULT 1,
    is_approved      TINYINT(1)   NOT NULL DEFAULT 0,
    created_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_city     (city),
    INDEX idx_cuisine  (cuisine_type),
    FULLTEXT INDEX ft_search (name, cuisine_type, description)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 4. MENU CATEGORIES
-- ─────────────────────────────────────────
CREATE TABLE menu_categories (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT UNSIGNED NOT NULL,
    name          VARCHAR(100) NOT NULL,
    sort_order    TINYINT UNSIGNED NOT NULL DEFAULT 0,
    is_active     TINYINT(1)  NOT NULL DEFAULT 1,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE,
    INDEX idx_restaurant (restaurant_id)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 5. MENU ITEMS
-- ─────────────────────────────────────────
CREATE TABLE menu_items (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT UNSIGNED  NOT NULL,
    category_id   INT UNSIGNED  DEFAULT NULL,
    name          VARCHAR(150)  NOT NULL,
    description   TEXT          DEFAULT NULL,
    price         DECIMAL(10,2) NOT NULL,
    image_url     VARCHAR(500)  DEFAULT NULL,
    is_veg        TINYINT(1)   NOT NULL DEFAULT 1,
    is_available  TINYINT(1)   NOT NULL DEFAULT 1,
    is_featured   TINYINT(1)   NOT NULL DEFAULT 0,
    spice_level   TINYINT UNSIGNED NOT NULL DEFAULT 0,  -- 0=none 1=mild 2=medium 3=hot
    calories      INT UNSIGNED  DEFAULT NULL,
    sort_order    SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id)   REFERENCES menu_categories(id) ON DELETE SET NULL,
    INDEX idx_restaurant (restaurant_id),
    INDEX idx_featured   (is_featured)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 6. COUPONS
-- ─────────────────────────────────────────
CREATE TABLE coupons (
    id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code             VARCHAR(30)   NOT NULL UNIQUE,
    description      VARCHAR(255)  DEFAULT NULL,
    discount_type    ENUM('flat','percent') NOT NULL DEFAULT 'flat',
    discount_value   DECIMAL(10,2) NOT NULL,
    min_order_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    max_discount     DECIMAL(10,2) DEFAULT NULL,
    usage_limit      INT UNSIGNED  DEFAULT NULL,
    used_count       INT UNSIGNED  NOT NULL DEFAULT 0,
    valid_from       DATE          NOT NULL,
    valid_until      DATE          NOT NULL,
    is_active        TINYINT(1)   NOT NULL DEFAULT 1,
    INDEX idx_code (code)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 7. ORDERS
-- ─────────────────────────────────────────
CREATE TABLE orders (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_number      VARCHAR(20)   NOT NULL UNIQUE,
    customer_id       INT UNSIGNED  NOT NULL,
    restaurant_id     INT UNSIGNED  NOT NULL,
    delivery_agent_id INT UNSIGNED  DEFAULT NULL,
    address_id        INT UNSIGNED  NOT NULL,
    coupon_id         INT UNSIGNED  DEFAULT NULL,
    status            ENUM(
                        'pending','confirmed','preparing',
                        'ready','picked_up','delivered','cancelled'
                      ) NOT NULL DEFAULT 'pending',
    payment_method    ENUM('cod','online','wallet') NOT NULL DEFAULT 'cod',
    payment_status    ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
    subtotal          DECIMAL(10,2) NOT NULL,
    delivery_fee      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount_amount   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    tax_amount        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total_amount      DECIMAL(10,2) NOT NULL,
    special_instructions TEXT        DEFAULT NULL,
    estimated_delivery DATETIME     DEFAULT NULL,
    delivered_at      DATETIME      DEFAULT NULL,
    cancelled_reason  VARCHAR(255)  DEFAULT NULL,
    created_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id)       REFERENCES users(id),
    FOREIGN KEY (restaurant_id)     REFERENCES restaurants(id),
    FOREIGN KEY (delivery_agent_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (address_id)        REFERENCES addresses(id),
    FOREIGN KEY (coupon_id)         REFERENCES coupons(id) ON DELETE SET NULL,
    INDEX idx_customer    (customer_id),
    INDEX idx_restaurant  (restaurant_id),
    INDEX idx_status      (status),
    INDEX idx_created     (created_at)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 8. ORDER ITEMS
-- ─────────────────────────────────────────
CREATE TABLE order_items (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id     INT UNSIGNED  NOT NULL,
    menu_item_id INT UNSIGNED  NOT NULL,
    name         VARCHAR(150)  NOT NULL,   -- snapshot at order time
    price        DECIMAL(10,2) NOT NULL,   -- snapshot at order time
    quantity     TINYINT UNSIGNED NOT NULL DEFAULT 1,
    subtotal     DECIMAL(10,2) NOT NULL,
    notes        VARCHAR(255)  DEFAULT NULL,
    FOREIGN KEY (order_id)     REFERENCES orders(id)     ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id),
    INDEX idx_order (order_id)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 9. ORDER STATUS HISTORY
-- ─────────────────────────────────────────
CREATE TABLE order_status_history (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id   INT UNSIGNED NOT NULL,
    status     VARCHAR(30)  NOT NULL,
    changed_by INT UNSIGNED DEFAULT NULL,
    note       VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id)   REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by) REFERENCES users(id)  ON DELETE SET NULL,
    INDEX idx_order (order_id)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 10. REVIEWS
-- ─────────────────────────────────────────
CREATE TABLE reviews (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id      INT UNSIGNED  NOT NULL UNIQUE,
    customer_id   INT UNSIGNED  NOT NULL,
    restaurant_id INT UNSIGNED  NOT NULL,
    food_rating   TINYINT UNSIGNED NOT NULL,
    delivery_rating TINYINT UNSIGNED NOT NULL,
    comment       TEXT DEFAULT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id)      REFERENCES orders(id),
    FOREIGN KEY (customer_id)   REFERENCES users(id),
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id),
    INDEX idx_restaurant (restaurant_id)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 11. CART (session-less server cart)
-- ─────────────────────────────────────────
CREATE TABLE cart_items (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED  NOT NULL,
    menu_item_id INT UNSIGNED  NOT NULL,
    quantity     TINYINT UNSIGNED NOT NULL DEFAULT 1,
    notes        VARCHAR(255)  DEFAULT NULL,
    created_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_item (user_id, menu_item_id),
    FOREIGN KEY (user_id)      REFERENCES users(id)      ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- 12. NOTIFICATIONS
-- ─────────────────────────────────────────
CREATE TABLE notifications (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    title      VARCHAR(150) NOT NULL,
    body       TEXT         NOT NULL,
    type       VARCHAR(50)  DEFAULT 'info',
    is_read    TINYINT(1)  NOT NULL DEFAULT 0,
    ref_id     INT UNSIGNED DEFAULT NULL,
    ref_type   VARCHAR(30)  DEFAULT NULL,
    created_at TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_unread (user_id, is_read)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────
-- VIEWS
-- ─────────────────────────────────────────

CREATE OR REPLACE VIEW v_restaurant_summary AS
SELECT
    r.id, r.name, r.slug, r.cuisine_type,
    r.logo_url, r.cover_url, r.city,
    r.avg_rating, r.total_reviews,
    r.min_order_amount, r.delivery_fee,
    r.avg_delivery_min, r.is_open,
    COUNT(DISTINCT mi.id) AS total_items
FROM restaurants r
LEFT JOIN menu_items mi ON mi.restaurant_id = r.id AND mi.is_available = 1
WHERE r.is_approved = 1
GROUP BY r.id;

CREATE OR REPLACE VIEW v_order_detail AS
SELECT
    o.*,
    u.name  AS customer_name,
    u.phone AS customer_phone,
    r.name  AS restaurant_name,
    r.phone AS restaurant_phone,
    a.line1, a.city AS delivery_city, a.pincode,
    da.name AS agent_name,
    da.phone AS agent_phone
FROM orders o
JOIN users       u  ON u.id  = o.customer_id
JOIN restaurants r  ON r.id  = o.restaurant_id
JOIN addresses   a  ON a.id  = o.address_id
LEFT JOIN users  da ON da.id = o.delivery_agent_id;

-- ─────────────────────────────────────────
-- STORED PROCEDURES
-- ─────────────────────────────────────────

DELIMITER $$

-- Place Order
CREATE PROCEDURE sp_place_order(
    IN  p_customer_id   INT UNSIGNED,
    IN  p_restaurant_id INT UNSIGNED,
    IN  p_address_id    INT UNSIGNED,
    IN  p_coupon_code   VARCHAR(30),
    IN  p_payment_method ENUM('cod','online','wallet'),
    IN  p_special_inst  TEXT,
    OUT p_order_id      INT UNSIGNED,
    OUT p_order_number  VARCHAR(20)
)
BEGIN
    DECLARE v_subtotal       DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_delivery_fee   DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_discount       DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_tax            DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_total          DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_coupon_id      INT UNSIGNED  DEFAULT NULL;
    DECLARE v_disc_type      VARCHAR(10);
    DECLARE v_disc_val       DECIMAL(10,2);
    DECLARE v_max_disc       DECIMAL(10,2);
    DECLARE v_order_num      VARCHAR(20);

    -- Compute subtotal from cart
    SELECT COALESCE(SUM(ci.quantity * mi.price), 0)
    INTO   v_subtotal
    FROM   cart_items ci
    JOIN   menu_items mi ON mi.id = ci.menu_item_id
    WHERE  ci.user_id = p_customer_id
      AND  mi.restaurant_id = p_restaurant_id;

    -- Get delivery fee
    SELECT delivery_fee INTO v_delivery_fee
    FROM   restaurants WHERE id = p_restaurant_id;

    -- Apply coupon
    IF p_coupon_code IS NOT NULL AND p_coupon_code != '' THEN
        SELECT id, discount_type, discount_value, max_discount
        INTO   v_coupon_id, v_disc_type, v_disc_val, v_max_disc
        FROM   coupons
        WHERE  code        = p_coupon_code
          AND  is_active   = 1
          AND  valid_from  <= CURDATE()
          AND  valid_until >= CURDATE()
          AND  (usage_limit IS NULL OR used_count < usage_limit)
          AND  min_order_amount <= v_subtotal;

        IF v_coupon_id IS NOT NULL THEN
            IF v_disc_type = 'flat' THEN
                SET v_discount = LEAST(v_disc_val, v_subtotal);
            ELSE
                SET v_discount = v_subtotal * v_disc_val / 100;
                IF v_max_disc IS NOT NULL THEN
                    SET v_discount = LEAST(v_discount, v_max_disc);
                END IF;
            END IF;
            UPDATE coupons SET used_count = used_count + 1 WHERE id = v_coupon_id;
        END IF;
    END IF;

    SET v_tax   = ROUND((v_subtotal - v_discount) * 0.05, 2);
    SET v_total = v_subtotal + v_delivery_fee - v_discount + v_tax;

    SET v_order_num = CONCAT('TT', DATE_FORMAT(NOW(), '%y%m%d'),
                             LPAD(FLOOR(RAND() * 9999), 4, '0'));

    INSERT INTO orders (
        order_number, customer_id, restaurant_id, address_id,
        coupon_id, payment_method, payment_status,
        subtotal, delivery_fee, discount_amount, tax_amount, total_amount,
        special_instructions, status,
        estimated_delivery
    ) VALUES (
        v_order_num, p_customer_id, p_restaurant_id, p_address_id,
        v_coupon_id, p_payment_method, 'pending',
        v_subtotal, v_delivery_fee, v_discount, v_tax, v_total,
        p_special_inst, 'pending',
        DATE_ADD(NOW(), INTERVAL 45 MINUTE)
    );

    SET p_order_id     = LAST_INSERT_ID();
    SET p_order_number = v_order_num;

    -- Copy cart items → order items
    INSERT INTO order_items (order_id, menu_item_id, name, price, quantity, subtotal, notes)
    SELECT p_order_id, ci.menu_item_id, mi.name,
           mi.price, ci.quantity,
           ci.quantity * mi.price,
           ci.notes
    FROM   cart_items ci
    JOIN   menu_items mi ON mi.id = ci.menu_item_id
    WHERE  ci.user_id = p_customer_id
      AND  mi.restaurant_id = p_restaurant_id;

    -- Log status
    INSERT INTO order_status_history (order_id, status, changed_by, note)
    VALUES (p_order_id, 'pending', p_customer_id, 'Order placed');

    -- Clear cart
    DELETE ci FROM cart_items ci
    JOIN menu_items mi ON mi.id = ci.menu_item_id
    WHERE ci.user_id = p_customer_id
      AND mi.restaurant_id = p_restaurant_id;

END$$

-- Update restaurant average rating
CREATE PROCEDURE sp_update_restaurant_rating(IN p_restaurant_id INT UNSIGNED)
BEGIN
    UPDATE restaurants r
    SET avg_rating   = (SELECT ROUND(AVG((food_rating + delivery_rating) / 2), 2)
                        FROM   reviews WHERE restaurant_id = p_restaurant_id),
        total_reviews = (SELECT COUNT(*) FROM reviews WHERE restaurant_id = p_restaurant_id)
    WHERE r.id = p_restaurant_id;
END$$

DELIMITER ;

-- ─────────────────────────────────────────
-- TRIGGERS
-- ─────────────────────────────────────────

DELIMITER $$

CREATE TRIGGER trg_after_review_insert
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    CALL sp_update_restaurant_rating(NEW.restaurant_id);
END$$

CREATE TRIGGER trg_after_review_update
AFTER UPDATE ON reviews
FOR EACH ROW
BEGIN
    CALL sp_update_restaurant_rating(NEW.restaurant_id);
END$$

CREATE TRIGGER trg_order_status_history
AFTER UPDATE ON orders
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO order_status_history (order_id, status, note)
        VALUES (NEW.id, NEW.status, CONCAT('Status changed to ', NEW.status));
    END IF;
END$$

DELIMITER ;

-- ─────────────────────────────────────────
-- SEED DATA
-- ─────────────────────────────────────────

-- Admin user (password: admin123)
INSERT INTO users (name, email, phone, password_hash, role) VALUES
('Super Admin', 'admin@tummytaxi.com', '9000000000',
 '$2y$12$examplehashadmin', 'admin');

-- Sample restaurants
INSERT INTO users (name, email, phone, password_hash, role) VALUES
('Raj Sharma',   'raj@spicegarден.com', '9111111111', '$2y$12$hash1', 'restaurant_owner'),
('Priya Nair',   'priya@biryanibox.com','9222222222', '$2y$12$hash2', 'restaurant_owner'),
('Arjun Mehta',  'arjun@pizzapeak.com', '9333333333', '$2y$12$hash3', 'restaurant_owner');

INSERT INTO restaurants
(owner_id, name, slug, description, cuisine_type, address_line, city, pincode,
 phone, avg_rating, total_reviews, min_order_amount, delivery_fee, avg_delivery_min,
 is_open, is_approved)
VALUES
(2, 'Spice Garden', 'spice-garden',
 'Authentic North Indian cuisine with rich gravies and tandoor specialties.',
 'North Indian', 'Shop 12, MI Road', 'Jaipur', '302001',
 '9111111111', 4.5, 128, 199.00, 29.00, 35, 1, 1),

(3, 'Biryani Box', 'biryani-box',
 'Hyderabadi Dum Biryani cooked the traditional way.',
 'Hyderabadi', 'C-14, Vaishali Nagar', 'Jaipur', '302021',
 '9222222222', 4.7, 245, 249.00, 0.00, 40, 1, 1),

(4, 'Pizza Peak', 'pizza-peak',
 'New York style hand-tossed pizzas and loaded pastas.',
 'Italian', 'Ground Floor, Crystal Mall, Tonk Road', 'Jaipur', '302015',
 '9333333333', 4.3, 89, 299.00, 49.00, 30, 1, 1);

-- Menu categories
INSERT INTO menu_categories (restaurant_id, name, sort_order) VALUES
(1,'Starters',1),(1,'Main Course',2),(1,'Breads',3),(1,'Beverages',4),
(2,'Biryani',1),(2,'Starters',2),(2,'Desserts',3),
(3,'Pizzas',1),(3,'Pastas',2),(3,'Sides',3);

-- Menu items for Spice Garden
INSERT INTO menu_items (restaurant_id,category_id,name,description,price,is_veg,spice_level,is_featured) VALUES
(1,1,'Paneer Tikka','Marinated cottage cheese grilled in tandoor',220.00,1,2,1),
(1,1,'Seekh Kebab','Minced lamb kebabs with aromatic spices',280.00,0,2,0),
(1,2,'Butter Chicken','Creamy tomato-based chicken curry',320.00,0,1,1),
(1,2,'Dal Makhani','Slow-cooked black lentils in butter and cream',220.00,1,1,1),
(1,2,'Palak Paneer','Cottage cheese in spiced spinach gravy',260.00,1,2,0),
(1,3,'Butter Naan','Soft leavened bread baked in tandoor',45.00,1,0,0),
(1,3,'Garlic Roti','Whole wheat bread with garlic',40.00,1,0,0),
(1,4,'Lassi Sweet','Traditional chilled yogurt drink',80.00,1,0,0);

-- Menu items for Biryani Box
INSERT INTO menu_items (restaurant_id,category_id,name,description,price,is_veg,spice_level,is_featured) VALUES
(2,5,'Chicken Dum Biryani','Slow-cooked Hyderabadi biryani with tender chicken',380.00,0,3,1),
(2,5,'Mutton Biryani','Rich aromatic mutton biryani',450.00,0,3,1),
(2,5,'Veg Dum Biryani','Fragrant biryani with seasonal vegetables',280.00,1,2,0),
(2,6,'Chicken 65','Spicy deep-fried chicken appetizer',280.00,0,3,0),
(2,6,'Mirchi Bajji','Stuffed green chilli fritters',120.00,1,3,0),
(2,7,'Double Ka Meetha','Traditional Hyderabadi bread pudding',120.00,1,0,1),
(2,7,'Qubani ka Meetha','Apricot dessert with custard',140.00,1,0,0);

-- Menu items for Pizza Peak
INSERT INTO menu_items (restaurant_id,category_id,name,description,price,is_veg,spice_level,is_featured) VALUES
(3,8,'Margherita','Classic tomato, mozzarella, fresh basil',349.00,1,0,0),
(3,8,'Pepperoni Feast','Double pepperoni with mozzarella',499.00,0,1,1),
(3,8,'BBQ Chicken','Smoky BBQ sauce, grilled chicken, caramelised onion',479.00,0,1,1),
(3,8,'Paneer Tikka Pizza','Spiced paneer with capsicum and onion',429.00,1,2,1),
(3,9,'Arrabbiata Pasta','Penne in spicy tomato sauce',299.00,1,2,0),
(3,9,'Chicken Alfredo','Creamy white sauce pasta with grilled chicken',349.00,0,0,0),
(3,10,'Garlic Bread','Toasted with herb butter and garlic',149.00,1,0,0),
(3,10,'Coleslaw','Creamy cabbage slaw',89.00,1,0,0);

-- Coupons
INSERT INTO coupons (code, description, discount_type, discount_value, min_order_amount, max_discount, valid_from, valid_until) VALUES
('WELCOME50', 'Welcome offer – 50% off first order', 'percent', 50, 199, 100, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 365 DAY)),
('FLAT100',   'Flat ₹100 off on orders above ₹499',  'flat',    100, 499, NULL, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 90 DAY)),
('TAXI20',    '20% off sitewide',                     'percent',  20, 299,  80, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 180 DAY));

-- Sample customer
INSERT INTO users (name, email, phone, password_hash, role) VALUES
('Demo Customer', 'customer@demo.com', '9876543210',
 '$2y$12$examplehashcustomer', 'customer');

INSERT INTO addresses (user_id, label, line1, city, state, pincode, is_default) VALUES
(5, 'Home', 'B-12, Malviya Nagar', 'Jaipur', 'Rajasthan', '302017', 1);
