<?php
// backend/api/orders.php

require_once __DIR__ . '/../config/helpers.php';

$db     = Database::connect();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

// GET user orders / single order
if ($method === 'GET') {
    $auth = require_auth();

    if ($id) {
        $stmt = $db->prepare(
            'SELECT o.*, r.name AS restaurant_name, r.logo_url,
                    a.line1, a.city AS delivery_city, a.pincode
             FROM orders o
             JOIN restaurants r ON r.id = o.restaurant_id
             JOIN addresses   a ON a.id = o.address_id
             WHERE o.id = ? AND o.customer_id = ?'
        );
        $stmt->execute([$id, $auth['id']]);
        $order = $stmt->fetch();
        if (!$order) error('Order not found', 404);

        $stmt = $db->prepare('SELECT * FROM order_items WHERE order_id = ?');
        $stmt->execute([$id]);
        $order['items'] = $stmt->fetchAll();

        $stmt = $db->prepare('SELECT status, note, created_at FROM order_status_history WHERE order_id = ? ORDER BY id');
        $stmt->execute([$id]);
        $order['history'] = $stmt->fetchAll();

        success($order);
    }

    // List orders
    $stmt = $db->prepare(
        'SELECT o.id, o.order_number, o.status, o.total_amount,
                o.created_at, o.estimated_delivery,
                r.name AS restaurant_name, r.logo_url,
                COUNT(oi.id) AS item_count
         FROM orders o
         JOIN restaurants r  ON r.id = o.restaurant_id
         JOIN order_items oi ON oi.order_id = o.id
         WHERE o.customer_id = ?
         GROUP BY o.id
         ORDER BY o.created_at DESC
         LIMIT 50'
    );
    $stmt->execute([$auth['id']]);
    success($stmt->fetchAll());
}

// POST – place order
if ($method === 'POST') {
    $auth = require_auth(['customer']);
    $body = get_body();
    validate($body, [
        'restaurant_id'  => 'required',
        'address_id'     => 'required',
        'payment_method' => 'required',
    ]);

    // Verify address belongs to user
    $stmt = $db->prepare('SELECT id FROM addresses WHERE id = ? AND user_id = ?');
    $stmt->execute([$body['address_id'], $auth['id']]);
    if (!$stmt->fetch()) error('Invalid address');

    // Verify cart is not empty
    $stmt = $db->prepare(
        'SELECT COUNT(*) FROM cart_items ci
         JOIN menu_items mi ON mi.id = ci.menu_item_id
         WHERE ci.user_id = ? AND mi.restaurant_id = ?'
    );
    $stmt->execute([$auth['id'], $body['restaurant_id']]);
    if ($stmt->fetchColumn() == 0) error('Cart is empty');

    // Call stored procedure
    $stmt = $db->prepare('CALL sp_place_order(?,?,?,?,?,?,@order_id,@order_num)');
    $stmt->execute([
        $auth['id'],
        $body['restaurant_id'],
        $body['address_id'],
        $body['coupon_code'] ?? null,
        $body['payment_method'],
        $body['special_instructions'] ?? null,
    ]);
    $stmt->closeCursor();

    $row = $db->query('SELECT @order_id AS order_id, @order_num AS order_num')->fetch();

    // Notify restaurant (insert notification for owner)
    $stmt = $db->prepare(
        'INSERT INTO notifications (user_id, title, body, type, ref_id, ref_type)
         SELECT owner_id, "New Order Received",
                CONCAT("Order #", ?, " has been placed."),
                "order", ?, "order"
         FROM restaurants WHERE id = ?'
    );
    $stmt->execute([$row['order_num'], $row['order_id'], $body['restaurant_id']]);

    success([
        'order_id'     => (int)$row['order_id'],
        'order_number' => $row['order_num'],
    ], 'Order placed successfully!', 201);
}

// PUT – update order status (restaurant/agent/admin)
if ($method === 'PUT' && $id) {
    $auth   = require_auth(['restaurant_owner', 'delivery_agent', 'admin']);
    $body   = get_body();
    $status = $body['status'] ?? '';

    $allowed = ['confirmed','preparing','ready','picked_up','delivered','cancelled'];
    if (!in_array($status, $allowed)) error('Invalid status');

    $extra = '';
    $params = [$status];
    if ($status === 'delivered') { $extra = ', delivered_at = NOW()'; }
    if ($status === 'cancelled') {
        $extra     = ', cancelled_reason = ?';
        $params[]  = $body['reason'] ?? '';
    }

    $params[] = $id;
    $db->prepare("UPDATE orders SET status = ? $extra WHERE id = ?")
       ->execute($params);

    success([], 'Order status updated');
}

// DELETE – cancel order (customer, within 2 min)
if ($method === 'DELETE' && $id) {
    $auth = require_auth(['customer']);
    $stmt = $db->prepare(
        'SELECT id FROM orders
         WHERE id=? AND customer_id=? AND status="pending"
         AND TIMESTAMPDIFF(MINUTE, created_at, NOW()) <= 2'
    );
    $stmt->execute([$id, $auth['id']]);
    if (!$stmt->fetch()) error('Order cannot be cancelled');
    $db->prepare('UPDATE orders SET status="cancelled", cancelled_reason="Customer cancelled" WHERE id=?')
       ->execute([$id]);
    success([], 'Order cancelled');
}

error('Not found', 404);
