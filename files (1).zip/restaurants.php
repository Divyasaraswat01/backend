<?php
// backend/api/restaurants.php

require_once __DIR__ . '/../config/helpers.php';

$db     = Database::connect();
$method = $_SERVER['REQUEST_METHOD'];
$id     = (int)($_GET['id'] ?? 0);

// GET all restaurants (with optional filters)
if ($method === 'GET' && !$id) {
    $city    = trim($_GET['city'] ?? '');
    $cuisine = trim($_GET['cuisine'] ?? '');
    $search  = trim($_GET['search'] ?? '');
    $open    = isset($_GET['open']) ? (int)$_GET['open'] : null;
    $sort    = $_GET['sort'] ?? 'rating'; // rating | time | fee

    $where  = ['r.is_approved = 1'];
    $params = [];

    if ($city)    { $where[] = 'r.city LIKE ?';    $params[] = "%$city%"; }
    if ($cuisine) { $where[] = 'r.cuisine_type = ?'; $params[] = $cuisine; }
    if ($search)  { $where[] = '(r.name LIKE ? OR r.cuisine_type LIKE ?)';
                    $params[] = "%$search%"; $params[] = "%$search%"; }
    if ($open !== null) { $where[] = 'r.is_open = ?'; $params[] = $open; }

    $orderBy = match($sort) {
        'time' => 'r.avg_delivery_min ASC',
        'fee'  => 'r.delivery_fee ASC',
        default => 'r.avg_rating DESC',
    };

    $sql = 'SELECT r.*, COUNT(DISTINCT mi.id) AS total_items
            FROM restaurants r
            LEFT JOIN menu_items mi ON mi.restaurant_id = r.id AND mi.is_available = 1
            WHERE ' . implode(' AND ', $where) . '
            GROUP BY r.id
            ORDER BY ' . $orderBy;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    success($stmt->fetchAll());
}

// GET single restaurant with menu
if ($method === 'GET' && $id) {
    $stmt = $db->prepare('SELECT * FROM restaurants WHERE id = ? AND is_approved = 1');
    $stmt->execute([$id]);
    $rest = $stmt->fetch();
    if (!$rest) error('Restaurant not found', 404);

    // Get categories + items
    $stmt = $db->prepare(
        'SELECT mc.id AS category_id, mc.name AS category_name,
                mi.id, mi.name, mi.description, mi.price,
                mi.image_url, mi.is_veg, mi.spice_level,
                mi.is_featured, mi.calories
         FROM   menu_categories mc
         JOIN   menu_items mi ON mi.category_id = mc.id AND mi.is_available = 1
         WHERE  mc.restaurant_id = ?
         ORDER  BY mc.sort_order, mi.sort_order'
    );
    $stmt->execute([$id]);
    $rows = $stmt->fetchAll();

    // Group by category
    $menu = [];
    foreach ($rows as $row) {
        $catId = $row['category_id'];
        if (!isset($menu[$catId])) {
            $menu[$catId] = ['id' => $catId, 'name' => $row['category_name'], 'items' => []];
        }
        unset($row['category_id'], $row['category_name']);
        $menu[$catId]['items'][] = $row;
    }
    $rest['menu'] = array_values($menu);

    // Featured items
    $stmt = $db->prepare(
        'SELECT id, name, description, price, image_url, is_veg, spice_level
         FROM   menu_items
         WHERE  restaurant_id = ? AND is_featured = 1 AND is_available = 1
         LIMIT  6'
    );
    $stmt->execute([$id]);
    $rest['featured_items'] = $stmt->fetchAll();

    // Recent reviews
    $stmt = $db->prepare(
        'SELECT rv.food_rating, rv.delivery_rating, rv.comment, rv.created_at,
                u.name AS reviewer_name
         FROM   reviews rv
         JOIN   users u ON u.id = rv.customer_id
         WHERE  rv.restaurant_id = ?
         ORDER  BY rv.created_at DESC
         LIMIT  5'
    );
    $stmt->execute([$id]);
    $rest['reviews'] = $stmt->fetchAll();

    success($rest);
}

// POST – create restaurant (restaurant_owner only)
if ($method === 'POST') {
    $auth = require_auth(['restaurant_owner', 'admin']);
    $body = get_body();
    validate($body, [
        'name'         => 'required',
        'cuisine_type' => 'required',
        'address_line' => 'required',
        'city'         => 'required',
        'pincode'      => 'required',
        'phone'        => 'required',
    ]);
    $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $body['name'])) . '-' . time();
    $stmt = $db->prepare(
        'INSERT INTO restaurants
         (owner_id,name,slug,description,cuisine_type,address_line,city,pincode,phone,
          delivery_fee,min_order_amount,avg_delivery_min)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?)'
    );
    $stmt->execute([
        $auth['id'], $body['name'], $slug,
        $body['description'] ?? '',
        $body['cuisine_type'], $body['address_line'],
        $body['city'], $body['pincode'], $body['phone'],
        $body['delivery_fee'] ?? 0,
        $body['min_order_amount'] ?? 0,
        $body['avg_delivery_min'] ?? 30,
    ]);
    success(['id' => $db->lastInsertId()], 'Restaurant submitted for approval', 201);
}

// PUT – update restaurant
if ($method === 'PUT' && $id) {
    $auth = require_auth(['restaurant_owner', 'admin']);
    $body = get_body();
    $stmt = $db->prepare(
        'UPDATE restaurants SET
             description=?, cuisine_type=?, address_line=?, city=?,
             pincode=?, phone=?, delivery_fee=?, min_order_amount=?,
             avg_delivery_min=?, is_open=?
         WHERE id=? AND (owner_id=? OR ? = "admin")'
    );
    $stmt->execute([
        $body['description'] ?? '',
        $body['cuisine_type'] ?? '',
        $body['address_line'] ?? '',
        $body['city'] ?? '',
        $body['pincode'] ?? '',
        $body['phone'] ?? '',
        $body['delivery_fee'] ?? 0,
        $body['min_order_amount'] ?? 0,
        $body['avg_delivery_min'] ?? 30,
        $body['is_open'] ?? 1,
        $id, $auth['id'], $auth['role'],
    ]);
    success([], 'Restaurant updated');
}

error('Not found', 404);
